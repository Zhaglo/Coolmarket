package com.example.inflate;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.inflate.databinding.CoolmarketBinding;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CoolmarketBinding binding = CoolmarketBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        binding.Phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + binding.Phone.getText().toString()));
                startActivity(intent);
            }
        });



        binding.Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String choos = "Товары:" + "\n";
                String deliv = "Способ доставки: ";
                String comment = "Комментарий к заказу: ";
                String all_text;

                ArrayList<CheckBox> orders = new ArrayList<>();
                orders.add(binding.Chocolate);
                orders.add(binding.Fruits);
                orders.add(binding.Meat);
                orders.add(binding.Sea);
                orders.add(binding.Milk);
                orders.add(binding.Vegetables);

                for (CheckBox x : orders) {
                    if (x.isChecked()) {
                        choos += x.getText() + "\n";
                    }
                }

                if (binding.Deliver.isChecked()) {
                    deliv += (String) binding.Deliver.getText() + "\n";
                }
                else if (binding.Self.isChecked()) {
                    deliv += (String) binding.Self.getText() + "\n";
                }

                comment += String.valueOf(binding.Comment.getText());

                all_text = choos + "\n" + deliv + "\n" + comment;

                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"jagloig2005@gmail.com"});
                intent.putExtra(Intent.EXTRA_TEXT, all_text);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Напоминание о доставке");
                startActivity(intent);
            }
        });

    }
}
